"use server";

import { db } from "@/db";
import { entries } from "@/db/schema";
import { revalidatePath } from "next/cache";

export async function addEntry(formData: FormData) {
  const name = formData.get("name") as string;
  const email = formData.get("email") as string;
  const instagramHandle = formData.get("instagramHandle") as string;

  if (!name || !email || !instagramHandle) {
    return { error: "All fields are required" };
  }

  try {
    await db.insert(entries).values({
      name,
      email,
      instagramHandle,
    });
    revalidatePath("/");
    return { success: true };
  } catch (error) {
    console.error("Failed to add entry:", error);
    return { error: "Something went wrong. Please try again." };
  }
}

export async function getEntries() {
  try {
    return await db.select().from(entries);
  } catch (error) {
    console.error("Failed to fetch entries:", error);
    return [];
  }
}
