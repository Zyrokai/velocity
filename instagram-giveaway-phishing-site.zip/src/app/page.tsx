"use client";

import { useState } from "react";
import { addEntry } from "./actions";
import { Gift, ShieldCheck, Mail, User, Trophy, Camera } from "lucide-react";

const InstagramIcon = () => (
  <svg
    viewBox="0 0 24 24"
    width="24"
    height="24"
    stroke="currentColor"
    strokeWidth="2"
    fill="none"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
  </svg>
);


export default function GiveawayPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  async function handleSubmit(formData: FormData) {
    setIsSubmitting(true);
    setMessage(null);
    const result = await addEntry(formData);
    setIsSubmitting(false);

    if (result.success) {
      setMessage({ type: "success", text: "You're in! Good luck! 🎁" });
    } else {
      setMessage({ type: "error", text: result.error || "Failed to enter." });
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 text-white selection:bg-pink-500/30">
      <main className="container mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-screen">
        <div className="max-w-4xl w-full text-center mb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md rounded-full border border-white/20 mb-6">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-sm font-medium">Summer 2024 Mega Giveaway</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-pink-200 to-purple-200">
            Win a Brand New <br />
            iPhone 15 Pro Max
          </h1>
          <p className="text-xl text-purple-100/80 mb-8 max-w-2xl mx-auto leading-relaxed">
            Join our exclusive community giveaway. One lucky winner will be chosen at random on September 1st! 
            No purchase necessary to enter.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start w-full max-w-5xl">
          {/* Left Side: Info */}
          <div className="space-y-8 animate-in fade-in slide-in-from-left-4 duration-700 delay-150">
            <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-8 rounded-3xl space-y-6">
              <h2 className="text-2xl font-bold mb-4">How to Enter:</h2>
              <div className="flex gap-4">
                <div className="bg-pink-500/20 p-3 rounded-2xl h-fit">
                  <InstagramIcon />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Follow us on Instagram</h3>
                  <p className="text-white/60">Follow our official account to be eligible.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="bg-purple-500/20 p-3 rounded-2xl h-fit">
                  <ShieldCheck className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Fill the Form</h3>
                  <p className="text-white/60">Provide your correct details so we can contact you.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="bg-blue-500/20 p-3 rounded-2xl h-fit">
                  <Gift className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Wait for Results</h3>
                  <p className="text-white/60">Winners will be announced live on Instagram.</p>
                </div>
              </div>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-500/20 p-6 rounded-2xl">
              <p className="text-sm text-yellow-200/80 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" />
                Security Notice: We will NEVER ask for your password. Beware of scammers impersonating us.
              </p>
            </div>
          </div>

          {/* Right Side: Form */}
          <div className="bg-white text-gray-900 p-8 md:p-10 rounded-[2rem] shadow-2xl shadow-purple-500/20 animate-in fade-in slide-in-from-right-4 duration-700 delay-300">
            <h2 className="text-3xl font-bold mb-8 tracking-tight">Enter Giveaway</h2>
            <form action={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-700" htmlFor="name">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    placeholder="John Doe"
                    className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-700" htmlFor="email">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="john@example.com"
                    className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-700" htmlFor="instagramHandle">
                  Instagram Handle
                </label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400">
                    <InstagramIcon />
                  </div>
                  <input
                    id="instagramHandle"
                    name="instagramHandle"
                    type="text"
                    required
                    placeholder="@yourhandle"
                    className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-4 rounded-xl hover:shadow-lg hover:shadow-purple-500/30 transition-all active:scale-[0.98] disabled:opacity-70 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    Enter Giveaway Now
                    <Gift className="w-5 h-5" />
                  </>
                )}
              </button>

              {message && (
                <div
                  className={`p-4 rounded-xl text-center font-medium animate-in fade-in zoom-in-95 duration-300 ${
                    message.type === "success" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                  }`}
                >
                  {message.text}
                </div>
              )}
            </form>
            <p className="mt-6 text-center text-gray-500 text-sm">
              By entering, you agree to our Terms and Conditions.
            </p>
          </div>
        </div>

        <footer className="mt-24 text-center text-white/40 text-sm">
          <p>© 2024 Your Brand Giveaway. All rights reserved.</p>
          <p className="mt-2">Not affiliated with Instagram or Apple Inc.</p>
        </footer>
      </main>
    </div>
  );
}
