import { getEntries } from "../actions";
import { Trophy } from "lucide-react";

export default async function AdminPage() {
  const entries = await getEntries();

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Giveaway Dashboard</h1>
            <p className="text-gray-500">Manage and view all participants</p>
          </div>
          <div className="bg-white px-6 py-3 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-gray-500 font-medium uppercase tracking-wider">Total Entries</p>
              <p className="text-2xl font-bold text-indigo-600">{entries.length}</p>
            </div>
            <div className="bg-indigo-50 p-3 rounded-xl">
              <Trophy className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-[2rem] shadow-xl shadow-gray-200/50 border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50/50 border-b border-gray-100">
                  <th className="px-6 py-5 text-sm font-semibold text-gray-600 uppercase tracking-wider">Participant</th>
                  <th className="px-6 py-5 text-sm font-semibold text-gray-600 uppercase tracking-wider">Instagram</th>
                  <th className="px-6 py-5 text-sm font-semibold text-gray-600 uppercase tracking-wider">Date Entered</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {entries.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="px-6 py-20 text-center text-gray-400">
                      No entries found yet. Start promoting!
                    </td>
                  </tr>
                ) : (
                  entries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold">
                            {entry.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{entry.name}</p>
                            <p className="text-sm text-gray-500">{entry.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-pink-600 font-medium">
                          <span className="text-sm">{entry.instagramHandle}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {new Date(entry.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
