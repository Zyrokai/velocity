import { pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const entries = pgTable("entries", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  instagramHandle: varchar("instagram_handle", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
